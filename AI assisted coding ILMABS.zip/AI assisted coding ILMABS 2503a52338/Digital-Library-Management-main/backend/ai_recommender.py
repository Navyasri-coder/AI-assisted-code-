import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


def recommend_books(cursor, user_id):
    """Recommend available books similar to the user's borrowing history."""

    cursor.execute(
        "SELECT book_id FROM borrowings WHERE user_id = %s",
        (user_id,)
    )
    history = cursor.fetchall()

    if not history:
        return []

    borrowed_ids = {row["book_id"] for row in history}

    cursor.execute(
        """
        SELECT book_id, title, author, category, description, availability
        FROM books
        """
    )
    books = cursor.fetchall()

    if len(books) < 2:
        return []

    contents = []
    for book in books:
        contents.append(" ".join([
            str(book.get("title") or ""),
            str(book.get("author") or ""),
            str(book.get("category") or ""),
            str(book.get("description") or "")
        ]))

    vectorizer = TfidfVectorizer(stop_words="english")
    tfidf_matrix = vectorizer.fit_transform(contents)

    borrowed_indices = [
        i for i, book in enumerate(books)
        if book["book_id"] in borrowed_ids
    ]

    if not borrowed_indices:
        return []

    # Convert the sparse mean vector into a regular 2D NumPy array.
    user_profile = np.asarray(
        tfidf_matrix[borrowed_indices].mean(axis=0)
    ).reshape(1, -1)

    scores = cosine_similarity(user_profile, tfidf_matrix).flatten()

    recommendations = []
    for i, book in enumerate(books):
      

        # In this database, 1 means Available and 0 means Borrowed.
      

        recommendations.append({
            "book_id": book["book_id"],
            "title": book["title"],
            "author": book["author"],
            "category": book["category"],
            "description": book["description"],
            "availability": book["availability"],
            "similarity_score": round(float(scores[i]), 3)
        })

    recommendations.sort(
        key=lambda item: item["similarity_score"],
        reverse=True
    )
    return recommendations[:5]
